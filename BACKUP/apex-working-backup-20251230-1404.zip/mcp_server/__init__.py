"""MCP Server module"""
from .wealth_mcp import WealthMCP

__all__ = ["WealthMCP"]
